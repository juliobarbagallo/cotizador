/**
 * Autor: Rodrigo Chambi Q.
 * Mail:  filvovmax@gmail.com
 * web:   www.gitmedio.com
 */
jQuery(document).ready(function($) {
   //Aqui validar las cajas de texto
  $("#FormEntrar").submit(function(event) {
      event.preventDefault();

      )};
	
});