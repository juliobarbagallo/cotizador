
<html>

<head>

<title>Cruz cotizador.</title>

</head>

<body>

<form method="POST" action="./procesar.php">

<textarea name="listado" rows="40" cols="160"></textarea>
<br>
<input type="submit" name="procesar" value="Procesar"/>

<input type="reset" value="Cancelar"/>
<input align= "right" type="number" name="porcentaje" min="1" max="50">
</form>

<br>
<a href="./listado.php">Lista articulos.</a>
<br>
<a href="./descargas.php">Presupuestos.</a>


</body>

</html>
